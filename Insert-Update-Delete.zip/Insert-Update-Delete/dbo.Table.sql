﻿CREATE TABLE [dbo].[Table]
(
	[name] VARCHAR(50) NULL, 
    [city] VARCHAR(50) NULL, 
    [country] VARCHAR(50) NULL 
)
